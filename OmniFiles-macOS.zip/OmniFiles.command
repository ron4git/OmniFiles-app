#!/usr/bin/env bash
# ==============================================================================
# OmniFiles macOS Double-Click Launcher
# ==============================================================================

# Ensure proper working directory
cd "$(dirname "$0")"

# Locate Java Runtime
if [ -x "/opt/homebrew/opt/openjdk/bin/java" ]; then
    JAVA_BIN="/opt/homebrew/opt/openjdk/bin/java"
elif [ -x "$HOME/Library/Java/JavaVirtualMachines/openjdk.jdk/Contents/Home/bin/java" ]; then
    JAVA_BIN="$HOME/Library/Java/JavaVirtualMachines/openjdk.jdk/Contents/Home/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_BIN="$(command -v java)"
elif [ -x "$(/usr/libexec/java_home 2>/dev/null)/bin/java" ]; then
    JAVA_BIN="$(/usr/libexec/java_home)/bin/java"
else
    osascript -e 'display alert "Java Not Found" message "Unable to locate a Java runtime. Please install OpenJDK via Homebrew."'
    exit 1
fi

JAR_PATH="/Users/Shared/OmniFiles-macos-arm64-1.0.0.jar"

if [ ! -f "$JAR_PATH" ]; then
    osascript -e 'display alert "OmniFiles Not Found" message "Could not find OmniFiles JAR at /Users/Shared/OmniFiles-macos-arm64-1.0.0.jar"'
    exit 1
fi

exec "$JAVA_BIN" --enable-native-access=ALL-UNNAMED -jar "$JAR_PATH" "$@"
