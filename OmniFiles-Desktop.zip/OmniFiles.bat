@echo off
REM ============================================================================
REM OmniFiles Windows Desktop Launcher
REM Double-click OmniFiles.bat in File Explorer or run from Command Prompt
REM ============================================================================
setlocal EnableDelayedExpansion

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM 1. Locate OmniFiles.jar in the same folder as OmniFiles.bat
set "JAR_PATH=%SCRIPT_DIR%OmniFiles.jar"
if not exist "%JAR_PATH%" (
    for %%F in ("%SCRIPT_DIR%OmniFiles*.jar") do (
        set "JAR_PATH=%%~fF"
        goto :found_jar
    )
)
:found_jar

if not exist "%JAR_PATH%" (
    powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('Could not find OmniFiles.jar in ' + '%SCRIPT_DIR%' + '. Please keep OmniFiles.bat in the same folder as OmniFiles.jar.', 'OmniFiles Not Found')" 2>nul
    echo [ERROR] Could not find OmniFiles.jar in %SCRIPT_DIR%
    pause
    exit /b 1
)

REM 2. Locate Java 17+ Runtime (javaw.exe preferred for GUI launch without console window)
set "JAVA_BIN="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javaw.exe" set "JAVA_BIN=%JAVA_HOME%\bin\javaw.exe"
)
if not defined JAVA_BIN (
    where javaw.exe >nul 2>nul
    if !errorlevel! equ 0 set "JAVA_BIN=javaw.exe"
)
if not defined JAVA_BIN (
    where java.exe >nul 2>nul
    if !errorlevel! equ 0 set "JAVA_BIN=java.exe"
)
if not defined JAVA_BIN (
    for /d %%D in ("C:\Program Files\Eclipse Adoptium\jdk*" "C:\Program Files\Java\jdk*" "C:\Program Files\Microsoft\jdk*" "C:\Program Files\Android\Android Studio\jbr") do (
        if exist "%%~fD\bin\javaw.exe" (
            set "JAVA_BIN=%%~fD\bin\javaw.exe"
            goto :found_java
        )
    )
)
:found_java

if not defined JAVA_BIN (
    powershell -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('Java 17+ was not found on your PC. Please install OpenJDK 17 or 21 from adoptium.net.', 'Java Not Found')" 2>nul
    echo [ERROR] Java 17+ runtime not found. Please install OpenJDK 17+ from https://adoptium.net/
    pause
    exit /b 1
)

start "" "%JAVA_BIN%" -Djava.net.preferIPv4Stack=true --enable-native-access=ALL-UNNAMED -jar "%JAR_PATH%" %*
exit /b 0
