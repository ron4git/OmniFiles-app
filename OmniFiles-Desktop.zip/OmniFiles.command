#!/usr/bin/env bash
# ==============================================================================
# OmniFiles macOS Launcher & Gatekeeper Unblocker
# Double-click in Finder or run from Terminal: ./OmniFiles.command
# Optional: ./OmniFiles.command --install (Installs OmniFiles.app to /Applications)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Automatically strip macOS Gatekeeper quarantine attributes ("Apple could not verify...")
if command -v xattr >/dev/null 2>&1; then
    xattr -cr "$SCRIPT_DIR/OmniFiles.app" 2>/dev/null || true
    xattr -d com.apple.quarantine "$SCRIPT_DIR/OmniFiles.command" 2>/dev/null || true
    xattr -d com.apple.quarantine "$SCRIPT_DIR/OmniFiles.jar" 2>/dev/null || true
fi
if [ -d "$SCRIPT_DIR/OmniFiles.app" ]; then
    chmod +x "$SCRIPT_DIR/OmniFiles.app/Contents/MacOS/OmniFiles" 2>/dev/null || true
    if command -v codesign >/dev/null 2>&1; then
        codesign --force --deep --sign - "$SCRIPT_DIR/OmniFiles.app" 2>/dev/null || true
    fi
fi

# 2. Locate OmniFiles.jar in the SAME folder as this launcher (or inside OmniFiles.app)
JAR_PATH=""
if [ -f "$SCRIPT_DIR/OmniFiles.jar" ]; then
    JAR_PATH="$SCRIPT_DIR/OmniFiles.jar"
else
    FIRST_JAR="$(ls "$SCRIPT_DIR"/OmniFiles*.jar 2>/dev/null | head -n 1)"
    if [ -n "$FIRST_JAR" ] && [ -f "$FIRST_JAR" ]; then
        JAR_PATH="$FIRST_JAR"
    elif [ -f "$SCRIPT_DIR/OmniFiles.app/Contents/Resources/OmniFiles.jar" ]; then
        JAR_PATH="$SCRIPT_DIR/OmniFiles.app/Contents/Resources/OmniFiles.jar"
    fi
fi

if [ -z "$JAR_PATH" ] || [ ! -f "$JAR_PATH" ]; then
    MSG="Could not find OmniFiles.jar in $SCRIPT_DIR. Make sure OmniFiles.jar is in the same folder as OmniFiles.command."
    echo "[ERROR] $MSG"
    osascript -e "display alert \"OmniFiles.jar Not Found\" message \"$MSG\"" 2>/dev/null || true
    exit 1
fi

# 3. Optional: Install standalone OmniFiles.app into /Applications if requested
if [ "${1:-}" = "--install" ]; then
    echo "==> Installing OmniFiles.app to /Applications..."
    rm -rf "/Applications/OmniFiles.app"
    cp -R "$SCRIPT_DIR/OmniFiles.app" "/Applications/OmniFiles.app"
    mkdir -p "/Applications/OmniFiles.app/Contents/Resources"
    cp "$JAR_PATH" "/Applications/OmniFiles.app/Contents/Resources/OmniFiles.jar"
    chmod +x "/Applications/OmniFiles.app/Contents/MacOS/OmniFiles"
    xattr -cr "/Applications/OmniFiles.app" 2>/dev/null || true
    codesign --force --deep --sign - "/Applications/OmniFiles.app" 2>/dev/null || true
    echo "✔ Installed to /Applications/OmniFiles.app (Gatekeeper quarantine cleared)!"
    open "/Applications/OmniFiles.app"
    exit 0
fi

# 4. Locate Java Runtime (JDK 17+)
JAVA_BIN=""
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    JAVA_BIN="$JAVA_HOME/bin/java"
elif [ -x "/opt/homebrew/opt/openjdk/bin/java" ]; then
    JAVA_BIN="/opt/homebrew/opt/openjdk/bin/java"
elif [ -x "/opt/homebrew/opt/openjdk@21/bin/java" ]; then
    JAVA_BIN="/opt/homebrew/opt/openjdk@21/bin/java"
elif [ -x "/opt/homebrew/opt/openjdk@17/bin/java" ]; then
    JAVA_BIN="/opt/homebrew/opt/openjdk@17/bin/java"
elif [ -x "/usr/local/opt/openjdk/bin/java" ]; then
    JAVA_BIN="/usr/local/opt/openjdk/bin/java"
elif [ -x "/Applications/Android Studio.app/Contents/jbr/Contents/Home/bin/java" ]; then
    JAVA_BIN="/Applications/Android Studio.app/Contents/jbr/Contents/Home/bin/java"
elif [ -x "/usr/libexec/java_home" ] && /usr/libexec/java_home >/dev/null 2>&1; then
    JAVA_BIN="$(/usr/libexec/java_home)/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_BIN="$(command -v java)"
fi

if [ -z "$JAVA_BIN" ] || [ ! -x "$JAVA_BIN" ]; then
    MSG="Unable to locate a Java 17+ runtime. Install OpenJDK via Homebrew: brew install openjdk"
    echo "[ERROR] $MSG"
    osascript -e "display alert \"Java Runtime Not Found\" message \"$MSG\"" 2>/dev/null || true
    exit 1
fi

ICON_ARGS=()
if [ -f "$SCRIPT_DIR/OmniFiles.app/Contents/Resources/AppIcon.icns" ]; then
    ICON_ARGS=("-Xdock:name=OmniFiles" "-Xdock:icon=$SCRIPT_DIR/OmniFiles.app/Contents/Resources/AppIcon.icns")
fi

echo "==> Launching OmniFiles ($JAR_PATH)..."
echo "    (Tip: Run './OmniFiles.command --install' to install OmniFiles.app into /Applications)"
exec "$JAVA_BIN" "${ICON_ARGS[@]}" --enable-native-access=ALL-UNNAMED -jar "$JAR_PATH" "$@"
