#!/usr/bin/env bash
# ==============================================================================
# OmniFiles Linux Desktop Launcher & Shortcut Installer
# Usage:
#   ./OmniFiles.sh             (Launch OmniFiles)
#   ./OmniFiles.sh --install   (Create Linux Desktop Application Menu shortcut)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Locate OmniFiles.jar in the same folder as OmniFiles.sh
JAR_PATH=""
if [ -f "$SCRIPT_DIR/OmniFiles.jar" ]; then
    JAR_PATH="$SCRIPT_DIR/OmniFiles.jar"
else
    FIRST_JAR="$(ls "$SCRIPT_DIR"/OmniFiles*.jar 2>/dev/null | head -n 1)"
    if [ -n "$FIRST_JAR" ] && [ -f "$FIRST_JAR" ]; then
        JAR_PATH="$FIRST_JAR"
    fi
fi

if [ -z "$JAR_PATH" ] || [ ! -f "$JAR_PATH" ]; then
    echo "[ERROR] Could not find OmniFiles.jar in $SCRIPT_DIR"
    exit 1
fi

# 2. Optional: Install ~/.local/share/applications/omnifiles.desktop shortcut
if [ "${1:-}" = "--install" ]; then
    DESKTOP_DIR="$HOME/.local/share/applications"
    mkdir -p "$DESKTOP_DIR"
    DESKTOP_FILE="$DESKTOP_DIR/omnifiles.desktop"
    cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=OmniFiles
Comment=Smart Downloads Radar & Cross-Device Wi-Fi Drop
Exec="$SCRIPT_DIR/OmniFiles.sh"
Path=$SCRIPT_DIR
Terminal=false
Categories=Utility;FileTools;FileManager;Network;
EOF
    chmod +x "$DESKTOP_FILE" "$SCRIPT_DIR/OmniFiles.sh"
    echo "✔ Created Linux desktop launcher at $DESKTOP_FILE"
    exit 0
fi

# 3. Locate Java Runtime (JDK 17+)
JAVA_BIN=""
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    JAVA_BIN="$JAVA_HOME/bin/java"
elif command -v java >/dev/null 2>&1; then
    JAVA_BIN="$(command -v java)"
elif [ -x "/usr/lib/jvm/java-21-openjdk-amd64/bin/java" ]; then
    JAVA_BIN="/usr/lib/jvm/java-21-openjdk-amd64/bin/java"
elif [ -x "/usr/lib/jvm/java-17-openjdk-amd64/bin/java" ]; then
    JAVA_BIN="/usr/lib/jvm/java-17-openjdk-amd64/bin/java"
fi

if [ -z "$JAVA_BIN" ] || [ ! -x "$JAVA_BIN" ]; then
    echo "[ERROR] Java 17+ runtime not found. Install via: sudo apt install openjdk-21-jre"
    exit 1
fi

exec "$JAVA_BIN" -Djava.net.preferIPv4Stack=true --enable-native-access=ALL-UNNAMED -jar "$JAR_PATH" "$@"
